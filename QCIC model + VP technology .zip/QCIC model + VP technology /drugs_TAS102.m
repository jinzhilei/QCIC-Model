function Chem=drugs_TAS102(k_in_Chem,t)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
%% This function was used to give the average treatment regimen for TAS-102
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

k1=[1:1:5];

k2=[8:1:12]; 

K1=[k1 k2];

K2=28+K1;

K3=28+K2;

K4=28+K3;

K5=28+K4;

K6=28+K5;

k=[K1 K2 K3 K4 K5 K6];   

n=length(k);

for i=1:n

    if k(i) <= t && (k(i)+1/10) > t

        Chem=10*k_in_Chem;

         break;

    else

        Chem=0;
        
    end

end

end
