function Trag=drugs_bevacizumab(k_in_Trag,x)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
%% This function was used to give the average treatment regimen for bevacizumab
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

k=1:15:150;

n=length(k);

for i=1:n

        if k(i) <= x && (k(i)+1/10) > x

            Trag=10*k_in_Trag;

            break;

        else

            Trag=0;

        end
        
end

end
